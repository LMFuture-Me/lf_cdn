没有加壳，想抄就抄。就五百多行烂代码，有50行还是重复的没优化掉。

考完试了，爷最爱的英语砸了，草
下次没有100分+就不玩电脑辽
闲得无聊改了下，修了些蛋疼的东西。
暑假来了，做了个彩蛋，如果找不到直接打开文件夹里的EasterEGG.exe就行。
整半天才发现Network Checker函数有问题，重写了个，为离线模式做铺垫
下次干脆Multi Process算了。不对，多语言和离线还没整。话说爷用MFC整GUI还是Qt，我想搞Material Design风格的。
还有几天放暑假，可以随便整了
很多函数重新写了，Bug少了不少，更不会主菜单输入奇奇怪怪字符就无限循环卡死。
试着做了个版本检测，省的有人不知道版本乱搞。
反正我也不求啥，不喜勿喷

加了自动更新，MD5验证，不会补齐文件，补齐文件下次再说，每次打开都会检查更新再启动。整半天才发现我直接把fgets的返回值拿来用了。。。

BUG REPORT EMAIL BUG反馈邮箱： 2835365572zty@gmail.com & zty2333@mail.litefish.top & zty2333@outlook.com
建议都发一遍。第一个邮箱我有时梯子到期，第二个域名邮箱不知道啥时候又会炸，第三个我不常用。


                          LiteFish Studio
                          @Copyright 2020


Thanks:
1. Microsoft Windows
2. 零散坑
3. LLVM
4. Microsoft VisualStudio&MSVC
5. Notepad++
6. CSDN
7. CURL
ETC...